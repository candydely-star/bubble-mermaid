plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.partytown.bubblepet"
    compileSdk = 35
    defaultConfig { applicationId = "com.partytown.bubblepet"; minSdk = 26; targetSdk = 35; versionCode = 48; versionName = "6.5A-4.8" }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

}
