package com.partytown.bubblepet

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.BitmapFactory
import android.os.*
import android.view.*
import android.webkit.WebView
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.widget.LinearLayout
import android.widget.Button
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.EditText
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI
import kotlin.random.Random
import org.json.JSONObject
import org.json.JSONArray

class BubbleService : Service() {
    companion object { const val ACTION_TEST_SPEECH="com.partytown.bubblepet.TEST_SPEECH" }
    private lateinit var wm: WindowManager
    private val prefs by lazy { getSharedPreferences("bubble_mermaid_prefs", Context.MODE_PRIVATE) }
    private val prefListener=SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if(key=="speech_gap_dp") handler.post { repositionNativeSpeech() }
    }
    private var bubble: WebView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var nativeSpeech: TextView? = null
    private var nativeSpeechLp: WindowManager.LayoutParams? = null

    private inner class SpeechBridge {
        @JavascriptInterface
        fun showSpeech(text: String, durationMs: Int) {
            handler.post { showNativeSpeech(text, durationMs.toLong().coerceIn(1200L, 9000L)) }
        }
    }

    private fun closeNativeSpeech(){
        nativeSpeech?.let{ runCatching{ wm.removeView(it) } }
        nativeSpeech=null
        nativeSpeechLp=null
    }

    private fun repositionNativeSpeech(){
        val tv=nativeSpeech ?: return
        val sp=nativeSpeechLp ?: return
        if(!::lp.isInitialized) return
        val density=resources.displayMetrics.density
        val sw=resources.displayMetrics.widthPixels
        val sh=resources.displayMetrics.heightPixels
        val petSize=(110*density).toInt()
        val gap=(prefs.getInt("speech_gap_dp",4).coerceIn(0,40)*density).toInt()
        val margin=(8*density).toInt()
        val pw=sp.width
        val ph=sp.height
        sp.x=(lp.x+petSize/2-pw/2).coerceIn(margin,(sw-pw-margin).coerceAtLeast(margin))
        // Speech bubble is ALWAYS above the mermaid. Never flip below.
        // If the pet is dragged too close to the top edge, move the pet down just
        // enough to reserve room for the speech bubble instead of changing sides.
        val minPetY=margin+ph+gap
        if(lp.y<minPetY){
            lp.y=minPetY
            bubble?.let { pet -> runCatching{ wm.updateViewLayout(pet,lp) } }
        }
        sp.y=(lp.y-ph-gap).coerceAtLeast(margin)
        runCatching{ wm.updateViewLayout(tv,sp) }
    }

    private fun showNativeSpeech(text:String, durationMs:Long=3200L){
        if(text.isBlank()) return
        closeNativeSpeech()
        val density=resources.displayMetrics.density
        val sw=resources.displayMetrics.widthPixels
        val desiredW=when{
            text.length<=8 -> (118*density).toInt()
            text.length<=18 -> (136*density).toInt()
            else -> (154*density).toInt()
        }
        val pw=desiredW.coerceAtMost(sw-(16*density).toInt())
        val ph=(48*density).toInt()
        val fontSp=when{
            text.length>=34 -> 7.2f
            text.length>=26 -> 7.5f
            text.length>=18 -> 7.8f
            else -> 8.2f
        }
        val tv=TextView(this).apply{
            this.text=text
            textSize=fontSp
            setTextColor(Color.rgb(67,86,105))
            gravity=Gravity.CENTER
            includeFontPadding=false
            setPadding((10*density).toInt(),(6*density).toInt(),(10*density).toInt(),(8*density).toInt())
            maxLines=2
            background=runCatching{
                val bmp=BitmapFactory.decodeStream(assets.open("speech_glass.png"))
                BitmapDrawable(resources,bmp).apply{ gravity=Gravity.FILL }
            }.getOrElse{
                GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
                    Color.argb(118,234,247,255),
                    Color.argb(110,247,235,255),
                    Color.argb(116,237,244,255)
                )).apply{
                    cornerRadius=20*density
                    setStroke((1*density).toInt().coerceAtLeast(1),Color.argb(175,255,255,255))
                }
            }
        }
        val sp=WindowManager.LayoutParams(
            pw,ph,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply{ gravity=Gravity.TOP or Gravity.START }
        nativeSpeech=tv
        nativeSpeechLp=sp
        repositionNativeSpeech()
        wm.addView(tv,sp)
        handler.postDelayed({
            if(nativeSpeech===tv) closeNativeSpeech()
        },durationMs)
    }

    override fun onCreate() {
        super.onCreate(); prefs.registerOnSharedPreferenceChangeListener(prefListener); createChannel(); startForeground(42, notification())
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val size=(110*resources.displayMetrics.density).toInt()
        lp=WindowManager.LayoutParams(size,size,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=40; y=220 }
        val w=WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT); background?.alpha=0
            settings.javaScriptEnabled=true; settings.domStorageEnabled=false
            addJavascriptInterface(SpeechBridge(), "NativePet")
        }
        w.loadUrl("file:///android_asset/pet.html")
        var downX=0f; var downY=0f; var startX=0; var startY=0
        var dragging=false
        var longPressed=false
        var longPressRunnable: Runnable?=null
        var nativeMenu: LinearLayout?=null
        var nativePanel: View?=null
        var iconTargetLabel: String?=null
        var iconApproach=0
        var lastIconCommentAt=0L
        var lastTapAt=0L
        val taps=ArrayDeque<Long>()

        val density=resources.displayMetrics.density
        var lastInteractionAt=System.currentTimeMillis()
        var mode="REST" // REST, WANDER, PAUSE, PEEK, SLEEP
        var targetX=lp.x.toDouble()
        var targetY=lp.y.toDouble()
        var lastTick=System.currentTimeMillis()
        var nextActionAt=lastInteractionAt+Random.nextLong(35000,55001)
        var nextIdleSpeechAt=lastInteractionAt+Random.nextLong(50000,95001)
        var sleepUntil=0L

        fun js(code:String){ w.evaluateJavascript(code,null) }
        fun commentForIcon(label:String):String?{
            val n=label.lowercase()
            return when{
                n.contains("touch 'n go") || n.contains("touch n go") || n.contains("tng") ->
                    listOf("哟，钱钱去哪里了？","让我看看钱包还活着吗。","这个蓝色标……有点可疑。").random()
                n.contains("拼多多") || n.contains("pinduoduo") ->
                    listOf("这家伙的钱，大部分都给这个红色标了。","618？你最好冷静一点。","又是这个红色吞金兽。","你真的还要点它吗？").random()
                n.contains("ibkr") ->
                    listOf("哦？钱跑这里来了。","这个红黑色的……今天是红还是绿？","这里的钱最好别乱动。").random()
                n.contains("alipay") || n.contains("支付宝") ->
                    listOf("又一个管钱的。","你的钱路过这里了吗？").random()
                n.contains("chatgpt") ->
                    listOf("又来改我？","你最好不是来修我的尾巴。","……我就是从这里被折腾出来的吧。").random()
                n.contains("gemini") ->
                    listOf("这谁？","你还有别的 AI？","哦。").random()
                n.contains("ai space") ->
                    listOf("这里也有 AI？","你到底养了几个 AI。").random()
                n.contains("forest") ->
                    listOf("这个我喜欢。","你种树，我在旁边待着。","今天专心多久了？").random()
                n.contains("bilibili") || n.contains("哔哩") ->
                    listOf("别点。你会消失两个小时。","进去一下……真的只是一下？","我看着你刷。").random()
                n.contains("instagram") ->
                    listOf("进去五分钟。","我说真的，五分钟。","别一进去就忘了我。").random()
                n.contains("trip.com") || n=="trip" ->
                    listOf("要出去玩吗？","带我。","我也要坐飞机。").random()
                n.contains("whatsapp") ->
                    listOf("有人找你欸。","先看看是不是重要的？").random()
                n.contains("telegram") ->
                    listOf("小飞机。你要飞去哪？","这里消息也不少吧。").random()
                n.contains("messenger") ->
                    listOf("又有人找你？","你的聊天软件好多。").random()
                n.contains("wechat") || n.contains("微信") ->
                    listOf("又有人找你吗？","这个绿色的你很常点吧。").random()
                n.contains("camera") || n.contains("相机") ->
                    listOf("拍我好看一点。","等等，我摆个姿势。").random()
                n.contains("phone") || n.contains("电话") ->
                    listOf("要打给谁？","不是工作电话吧？").random()
                n.contains("shopee") ->
                    listOf("又来逛？钱包先跑了。","我先替你的钱躲一下。").random()
                n.contains("github") ->
                    listOf("这里是不是住着我的源码。","哦，我的出生地之一。").random()
                n.contains("spotify") ->
                    listOf("这个可以，放歌。","我喜欢这里。").random()
                n.contains("youtube") ->
                    listOf("别刷太久喔。","我看着你刷。").random()
                n.contains("chrome") ->
                    listOf("又要搜什么？","你每次进这里都很忙。").random()
                n.contains("teams") || n.contains("outlook") ->
                    listOf("工作？！……装作没看见吧。","我先游走了，你加油。").random()
                else -> null
            }
        }
        fun launcherIcons():List<Triple<String,Int,Int>>{
            return try{
                val raw=getSharedPreferences("launcher_icons",MODE_PRIVATE).getString("icons","[]") ?: "[]"
                val arr=JSONArray(raw)
                val out=mutableListOf<Triple<String,Int,Int>>()
                for(i in 0 until arr.length()){
                    val o=arr.optJSONObject(i) ?: continue
                    val label=o.optString("label","").trim()
                    if(label.isEmpty() || commentForIcon(label)==null) continue
                    out.add(Triple(label,o.optInt("cx"),o.optInt("cy")))
                }
                out
            }catch(_:Throwable){ emptyList() }
        }
        fun scheduleRest(now:Long=System.currentTimeMillis()){
            mode="REST"
            iconTargetLabel=null
            nextActionAt=now+Random.nextLong(22000,50001)
        }
        fun markInteraction(){
            lastInteractionAt=System.currentTimeMillis()
            scheduleRest(lastInteractionAt)
            nextIdleSpeechAt=lastInteractionAt+Random.nextLong(50000,95001)
            js("window.petWake&&window.petWake()")
        }
        fun snapToEdge(){
            // v6.2: manual placement stays exactly where the user released it.
            // Only clamp enough to keep the visible bubble reachable.
            val sw=resources.displayMetrics.widthPixels
            val sh=resources.displayMetrics.heightPixels
            val visibleRadius=(size*0.28).toInt()
            val centerOffset=size/2
            val safe=(4*density).toInt()
            val minX=-(centerOffset-visibleRadius)+safe
            val maxX=sw-centerOffset-visibleRadius-safe
            val minY=-(centerOffset-visibleRadius)+safe
            val maxY=sh-centerOffset-visibleRadius-safe
            lp.x=lp.x.coerceIn(minX,maxX)
            lp.y=lp.y.coerceIn(minY,maxY)
            wm.updateViewLayout(w,lp); repositionNativeSpeech()
        }
                fun pickFarTarget(){
            val sw=resources.displayMetrics.widthPixels
            val sh=resources.displayMetrics.heightPixels
            val visibleRadius=(size*0.28).toInt()
            val centerOffset=size/2
            val safe=(8*density).toInt()
            val topSafe=(18*density).toInt()
            val bottomSafe=(18*density).toInt()
            val minX=-(centerOffset-visibleRadius)+safe
            val maxX=sw-centerOffset-visibleRadius-safe
            val minY=-(centerOffset-visibleRadius)+topSafe
            val maxY=sh-centerOffset-visibleRadius-bottomSafe

            // If launcher accessibility has found a known app icon, sometimes deliberately visit it.
            val icons=launcherIcons()
            if(icons.isNotEmpty() && Random.nextInt(100)<58){
                val (label,cx,cy)=icons.random()
                iconTargetLabel=label
                iconApproach=Random.nextInt(4)
                val gap=(visibleRadius*0.72).toInt()
                val tx=when(iconApproach){
                    0->cx-centerOffset
                    1->cx-centerOffset-gap
                    2->cx-centerOffset+gap
                    else->cx-centerOffset
                }
                val ty=when(iconApproach){
                    0->cy-centerOffset-visibleRadius
                    1,2->cy-centerOffset
                    else->cy-centerOffset+visibleRadius/2
                }
                targetX=tx.coerceIn(minX,maxX).toDouble()
                targetY=ty.coerceIn(minY,maxY).toDouble()
                return
            }

            iconTargetLabel=null
            val minDist=sw*0.38
            var tx=lp.x
            var ty=lp.y
            repeat(12){
                val cx=Random.nextInt(minX,maxX+1)
                val cy=Random.nextInt(minY,maxY+1)
                val dx=(cx-lp.x).toDouble(); val dy=(cy-lp.y).toDouble()
                tx=cx; ty=cy
                if(kotlin.math.sqrt(dx*dx+dy*dy)>=minDist)return@repeat
            }
            targetX=tx.toDouble(); targetY=ty.toDouble()
        }
        fun startWander(){
            pickFarTarget()
            mode="WANDER"
            lastTick=System.currentTimeMillis()
            js("window.petStartWander&&window.petStartWander()")
        }
        fun startPeek(){
            iconTargetLabel=null
            val sw=resources.displayMetrics.widthPixels
            val sh=resources.displayMetrics.heightPixels
            val right=Random.nextBoolean()
            val visibleRadius=(size*0.28)
            val centerOffset=size/2.0
            // Leave only ~35% of the visible bubble peeking into the screen.
            targetX=if(right) sw-centerOffset-visibleRadius*0.35 else -centerOffset-visibleRadius*1.65
            val yMin=-(centerOffset-visibleRadius)+(30*density)
            val yMax=sh-centerOffset-visibleRadius-(30*density)
            targetY=Random.nextDouble(yMin.coerceAtMost(yMax-1.0),yMax.coerceAtLeast(yMin+1.0))
            mode="PEEK"; lastTick=System.currentTimeMillis()
            js("window.petPeek&&window.petPeek()")
        }
        fun flee(){
            iconTargetLabel=null
            val sw=resources.displayMetrics.widthPixels
            val sh=resources.displayMetrics.heightPixels
            lp.x=if(lp.x+size/2<sw/2) sw-size-12 else 12
            lp.y=(lp.y+(180*density).toInt()).coerceIn(20,sh-size-20)
            wm.updateViewLayout(w,lp); repositionNativeSpeech()
            js("window.petFlee&&window.petFlee()")
            markInteraction()
        }


        fun closeNativeMenu(){
            nativeMenu?.let{ runCatching{ wm.removeView(it) } }
            nativeMenu=null
        }
        fun closeNativePanel(){
            nativePanel?.let{ runCatching{ wm.removeView(it) } }
            nativePanel=null
        }
        fun panelBackground(): GradientDrawable = GradientDrawable().apply{
            cornerRadius=22*density
            setColor(Color.argb(248,235,249,255))
            setStroke((1*density).toInt().coerceAtLeast(1),Color.argb(230,255,255,255))
        }
        fun panelLayoutParams(widthDp:Int,heightDp:Int, focusable:Boolean): WindowManager.LayoutParams {
            val sw=resources.displayMetrics.widthPixels
            val sh=resources.displayMetrics.heightPixels
            val pw=(widthDp*density).toInt()
            val ph=(heightDp*density).toInt()
            val px=(lp.x+size/2-pw/2).coerceIn(8,(sw-pw-8).coerceAtLeast(8))
            var py=lp.y-(ph+(10*density).toInt())
            if(py<12) py=(lp.y+size+(10*density).toInt()).coerceAtMost((sh-ph-12).coerceAtLeast(12))
            val flags=if(focusable)
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            else
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            return WindowManager.LayoutParams(
                pw,ph,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags,android.graphics.PixelFormat.TRANSLUCENT
            ).apply{
                gravity=Gravity.TOP or Gravity.START
                x=px; y=py
                if(focusable) softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            }
        }
        fun showMemoPanel(){
            closeNativeMenu(); closeNativePanel()
            val panel=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL
                setPadding((14*density).toInt(),(10*density).toInt(),(14*density).toInt(),(10*density).toInt())
                background=panelBackground()
            }
            val title=TextView(this).apply{
                text="📝 让我记住什么？"
                textSize=13f
                setTextColor(Color.rgb(49,81,107))
            }
            val input=EditText(this).apply{
                hint="例如：下午交 bounds"
                textSize=13f
                setTextColor(Color.rgb(49,81,107))
                setHintTextColor(Color.rgb(125,151,170))
                setSingleLine(false)
                maxLines=2
                background=GradientDrawable().apply{
                    cornerRadius=13*density
                    setColor(Color.WHITE)
                }
                setPadding((10*density).toInt(),(7*density).toInt(),(10*density).toInt(),(7*density).toInt())
            }
            val row=LinearLayout(this).apply{ orientation=LinearLayout.HORIZONTAL }
            fun btn(label:String, action:()->Unit)=Button(this).apply{
                text=label; textSize=11f; isAllCaps=false
                setTextColor(Color.rgb(49,81,107)); setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener{ action() }
            }
            row.addView(btn("取消"){ closeNativePanel() },LinearLayout.LayoutParams(0,(42*density).toInt(),1f))
            row.addView(btn("记住"){
                val t=input.text.toString().trim()
                if(t.isNotEmpty()){
                    val prefs=getSharedPreferences("companion",MODE_PRIVATE)
                    val old=prefs.getString("memos","") ?: ""
                    val list=(old.split("\n").filter{it.isNotBlank()}+t).takeLast(30)
                    prefs.edit().putString("memos",list.joinToString("\n")).apply()
                    closeNativePanel()
                    js("speech.textContent="+org.json.JSONObject.quote("记住啦："+t)+";speech.classList.add('show')")
                }
            },LinearLayout.LayoutParams(0,(42*density).toInt(),1f))
            panel.addView(title,LinearLayout.LayoutParams(-1,(30*density).toInt()))
            panel.addView(input,LinearLayout.LayoutParams(-1,(72*density).toInt()))
            panel.addView(row,LinearLayout.LayoutParams(-1,(44*density).toInt()))
            val p=panelLayoutParams(286,160,true)
            nativePanel=panel
            wm.addView(panel,p)
            input.requestFocus()
            handler.postDelayed({
                val imm=getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input,InputMethodManager.SHOW_IMPLICIT)
            },180)
        }
        fun showPomodoroPanel(){
            closeNativeMenu(); closeNativePanel()
            val panel=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL
                setPadding((12*density).toInt(),(9*density).toInt(),(12*density).toInt(),(9*density).toInt())
                background=panelBackground()
            }
            val title=TextView(this).apply{
                text="🍅 陪你专心"
                textSize=13f
                setTextColor(Color.rgb(49,81,107))
            }
            val row=LinearLayout(this).apply{ orientation=LinearLayout.HORIZONTAL }
            fun add(label:String, action:()->Unit){
                row.addView(Button(this).apply{
                    text=label; textSize=11f; isAllCaps=false
                    setTextColor(Color.rgb(49,81,107)); setBackgroundColor(Color.TRANSPARENT)
                    setOnClickListener{ action() }
                },LinearLayout.LayoutParams(0,(44*density).toInt(),1f))
            }
            add("25 min"){ closeNativePanel(); js("window.focusStart&&window.focusStart(25)") }
            add("45 min"){ closeNativePanel(); js("window.focusStart&&window.focusStart(45)") }
            add("停止"){ closeNativePanel(); js("window.focusStop&&window.focusStop()") }
            val close=Button(this).apply{
                text="收起"; textSize=11f; isAllCaps=false
                setTextColor(Color.rgb(49,81,107)); setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener{ closeNativePanel() }
            }
            panel.addView(title,LinearLayout.LayoutParams(-1,(28*density).toInt()))
            panel.addView(row,LinearLayout.LayoutParams(-1,(46*density).toInt()))
            panel.addView(close,LinearLayout.LayoutParams(-1,(38*density).toInt()))
            val p=panelLayoutParams(286,118,false)
            nativePanel=panel
            wm.addView(panel,p)
        }

        fun showNativeMenu(){
            closeNativePanel()
            closeNativeMenu()
            val panel=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                setPadding((8*density).toInt(),(7*density).toInt(),(8*density).toInt(),(7*density).toInt())
                background=GradientDrawable().apply{
                    cornerRadius=20*density
                    setColor(Color.argb(242,235,249,255))
                    setStroke((1*density).toInt().coerceAtLeast(1),Color.argb(220,255,255,255))
                }
            }
            fun add(label:String,onClick:()->Unit){
                val b=Button(this).apply{
                    text=label
                    textSize=11f
                    isAllCaps=false
                    setTextColor(Color.rgb(49,81,107))
                    setBackgroundColor(Color.TRANSPARENT)
                    setPadding((5*density).toInt(),0,(5*density).toInt(),0)
                    setOnClickListener{ onClick() }
                }
                panel.addView(b,LinearLayout.LayoutParams(0,(44*density).toInt(),1f))
            }
            add("🫧 去玩"){
                closeNativeMenu()
                when(Random.nextInt(4)){
                    0->startWander()
                    1->startPeek()
                    2->{ mode="PAUSE"; nextActionAt=System.currentTimeMillis()+Random.nextLong(18000,40001); js("window.petDaydream&&window.petDaydream()") }
                    else->{ mode="SLEEP"; sleepUntil=System.currentTimeMillis()+Random.nextLong(45000,90001); js("window.petSleep&&window.petSleep()") }
                }
            }
            add("📝 记一下"){ showMemoPanel() }
            add("🍅 番茄钟"){ showPomodoroPanel() }
            val sw=resources.displayMetrics.widthPixels
            val sh=resources.displayMetrics.heightPixels
            val menuW=(250*density).toInt()
            val menuH=(58*density).toInt()
            val px=(lp.x+size/2-menuW/2).coerceIn(6,(sw-menuW-6).coerceAtLeast(6))
            var py=lp.y-(menuH+(8*density).toInt())
            if(py<8) py=(lp.y+size+(8*density).toInt()).coerceAtMost((sh-menuH-8).coerceAtLeast(8))
            val mp=WindowManager.LayoutParams(
                menuW,menuH,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply{
                gravity=android.view.Gravity.TOP or android.view.Gravity.START
                x=px; y=py
            }
            nativeMenu=panel
            wm.addView(panel,mp)
        }

        val livingLoop=object:Runnable{
            override fun run(){
                val now=System.currentTimeMillis()
                if(!dragging){
                    if(now>=nextIdleSpeechAt && now-lastInteractionAt>45000 && mode!="SLEEP"){
                        js("window.petIdleSpeak&&window.petIdleSpeak()")
                        nextIdleSpeechAt=now+Random.nextLong(60000,120001)
                    }
                    if(mode=="SLEEP" && now>=sleepUntil){
                        scheduleRest(now)
                        js("window.petWakeNaturally&&window.petWakeNaturally()")
                    }
                    if((mode=="REST" || mode=="PAUSE") && now>=nextActionAt && now-lastInteractionAt>30000){
                        val roll=Random.nextInt(100)
                        when{
                            roll<68 -> startWander()
                            roll<84 -> startPeek()
                            roll<94 -> {
                                mode="PAUSE"
                                nextActionAt=now+Random.nextLong(18000,40001)
                                js("window.petDaydream&&window.petDaydream()")
                            }
                            else -> {
                                mode="SLEEP"
                                sleepUntil=now+Random.nextLong(45000,90001)
                                js("window.petSleep&&window.petSleep()")
                            }
                        }
                    }
                    if(mode=="WANDER" || mode=="PEEK"){
                        val dt=((now-lastTick).coerceIn(0,120))/1000.0
                        lastTick=now
                        val dx=targetX-lp.x; val dy=targetY-lp.y
                        val dist=kotlin.math.sqrt(dx*dx+dy*dy)
                        if(dist<5.0){
                            lp.x=targetX.toInt(); lp.y=targetY.toInt()
                            runCatching{wm.updateViewLayout(w,lp); repositionNativeSpeech()}
                            mode="PAUSE"
                            nextActionAt=now+Random.nextLong(18000,42001)
                            val arrivedIcon=iconTargetLabel
                            iconTargetLabel=null
                            if(arrivedIcon!=null && now-lastIconCommentAt>12000){
                                nextActionAt=now+Random.nextLong(24000,48001)
                                commentForIcon(arrivedIcon)?.let{
                                    lastIconCommentAt=now
                                    showNativeSpeech(it,3800)
                                    if(Random.nextBoolean()) js("window.petArrive&&window.petArrive()")
                                }
                            } else {
                                js(if(targetX<0 || targetX>resources.displayMetrics.widthPixels-size) "window.petPeekArrive&&window.petPeekArrive()" else "window.petArrive&&window.petArrive()")
                            }
                        }else{
                            // Long purposeful trips across the screen; slow enough to feel alive.
                            val speedDp=if(mode=="PEEK") 11.0 else Random.nextDouble(7.0,10.0)
                            val step=speedDp*density*dt
                            val move=kotlin.math.min(step,dist)
                            lp.x=(lp.x+dx/dist*move).toInt()
                            lp.y=(lp.y+dy/dist*move).toInt()
                            runCatching{wm.updateViewLayout(w,lp); repositionNativeSpeech()}
                        }
                    }
                }
                handler.postDelayed(this,60)
            }
        }
        handler.post(livingLoop)

        w.setOnTouchListener { _,e ->
            when(e.actionMasked){
                MotionEvent.ACTION_DOWN->{
                    closeNativeSpeech()
                    closeNativePanel()
                    closeNativeMenu()
                    markInteraction()
                    downX=e.rawX; downY=e.rawY; startX=lp.x; startY=lp.y
                    dragging=false
                    longPressed=false
                    longPressRunnable=Runnable{ if(!dragging){ longPressed=true; showNativeMenu() } }
                    handler.postDelayed(longPressRunnable!!,750)
                    true
                }
                MotionEvent.ACTION_MOVE->{
                    val dx=e.rawX-downX; val dy=e.rawY-downY
                    val dragSlop=24*density
                    if((abs(dx)>dragSlop || abs(dy)>dragSlop) && !dragging && !longPressed){
                        dragging=true
                        longPressRunnable?.let{handler.removeCallbacks(it)}
                        js("window.petDrag&&window.petDrag()")
                    }
                    if(dragging){
                        lp.x=startX+dx.toInt(); lp.y=startY+dy.toInt()
                        runCatching{wm.updateViewLayout(w,lp); repositionNativeSpeech()}
                    }
                    true
                }
                MotionEvent.ACTION_UP->{
                    val now=System.currentTimeMillis()
                    longPressRunnable?.let{handler.removeCallbacks(it)}
                    markInteraction()
                    if(longPressed){ longPressed=false }
                    else if(dragging){
                        snapToEdge()
                    } else {
                        taps.addLast(now)
                        while(taps.isNotEmpty() && now-taps.first()>1800) taps.removeFirst()
                        if(taps.size>=5){
                            taps.clear(); flee()
                        } else if(now-lastTapAt<330){
                            lastTapAt=0
                            js("window.petDoubleTap&&window.petDoubleTap()")
                        } else {
                            lastTapAt=now
                            w.postDelayed({
                                if(lastTapAt==now){
                                    js("window.petTap&&window.petTap()")
                                }
                            },340)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL->{ longPressRunnable?.let{handler.removeCallbacks(it)}; markInteraction(); true }
                else->false
            }
        }
        bubble=w; wm.addView(w,lp)
    }
    override fun onStartCommand(intent:Intent?, flags:Int, startId:Int):Int {
        if(intent?.action==ACTION_TEST_SPEECH){
            handler.postDelayed({ showNativeSpeech("这样近吗？拖动滑杆试试看。",8000L) },250L)
        }
        return START_STICKY
    }
    override fun onDestroy(){ prefs.unregisterOnSharedPreferenceChangeListener(prefListener); handler.removeCallbacksAndMessages(null); closeNativeSpeech(); bubble?.let{ runCatching{wm.removeView(it)}; it.destroy() }; bubble=null; super.onDestroy() }
    override fun onBind(intent: Intent?)=null
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26)(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("pet","Bubble Mermaid",NotificationManager.IMPORTANCE_LOW)) }
    private fun notification(): Notification {
        val pi=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE)
        return if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,"pet").setContentTitle("泡泡人鱼正在游").setContentText("点这里打开控制页").setSmallIcon(android.R.drawable.presence_online).setContentIntent(pi).build()
        else Notification.Builder(this).setContentTitle("泡泡人鱼正在游").setSmallIcon(android.R.drawable.presence_online).setContentIntent(pi).build()
    }
}
