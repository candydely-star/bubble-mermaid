package com.partytown.bubblepet

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(48,48,48,48) }
        val title = TextView(this).apply { text="🫧 Bubble Mermaid"; textSize=26f; gravity=Gravity.CENTER }
        val note = TextView(this).apply { text="Mini A542i 桌宠。对话框固定在人鱼上方；距离可自行调整。"; textSize=16f; gravity=Gravity.CENTER; setPadding(0,24,0,24) }
        val prefs=getSharedPreferences("bubble_mermaid_prefs", Context.MODE_PRIVATE)
        val distanceLabel=TextView(this).apply { textSize=14f; gravity=Gravity.CENTER; setPadding(0,10,0,0) }
        val distanceHint=TextView(this).apply { text="← 贴着人鱼     对话框距离     更远 →"; textSize=12f; gravity=Gravity.CENTER }
        val distanceSlider=SeekBar(this).apply { max=40; progress=prefs.getInt("speech_gap_dp",4).coerceIn(0,40) }
        fun updateDistanceLabel(gap:Int){
            distanceLabel.text=when{
                gap<=2 -> "对话框：贴着人鱼  (${gap}dp)"
                gap<=8 -> "对话框：很近  (${gap}dp)"
                gap<=16 -> "对话框：稍近  (${gap}dp)"
                gap<=26 -> "对话框：标准  (${gap}dp)"
                else -> "对话框：较远  (${gap}dp)"
            }
        }
        updateDistanceLabel(distanceSlider.progress)
        distanceSlider.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar:SeekBar?, progress:Int, fromUser:Boolean){
                val gap=progress
                updateDistanceLabel(gap)
                if(fromUser) prefs.edit().putInt("speech_gap_dp",gap).apply()
            }
            override fun onStartTrackingTouch(seekBar:SeekBar?){}
            override fun onStopTrackingTouch(seekBar:SeekBar?){}
        })
        val testSpeech=Button(this).apply { text="测试对话框位置" }
        val start = Button(this).apply { text="启动泡泡人鱼" }
        val stop = Button(this).apply { text="收起泡泡" }
        box.addView(title); box.addView(note); box.addView(distanceLabel); box.addView(distanceHint); box.addView(distanceSlider); box.addView(testSpeech); box.addView(start); box.addView(stop); setContentView(box)
        fun startPet(action:String?=null){
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val i=Intent(this, BubbleService::class.java).apply { this.action=action }
                ContextCompat.startForegroundService(this, i)
            }
        }
        testSpeech.setOnClickListener { startPet(BubbleService.ACTION_TEST_SPEECH) }
        start.setOnClickListener { startPet() }
        stop.setOnClickListener { stopService(Intent(this, BubbleService::class.java)) }
    }
    override fun onResume() { super.onResume() }
}

object ContextCompat { fun startForegroundService(c: Context, i: Intent) { if (android.os.Build.VERSION.SDK_INT>=26) c.startForegroundService(i) else c.startService(i) } }
